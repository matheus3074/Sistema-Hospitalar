package com.example.atividade_lanche02.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "lanches")
public class Lanche {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "nome")
    private String nome;

    @Column(name = "img_url")
    private String imgUrl;

    @Column(name = "preco")
    private double preco;

    public Lanche() {

    }

    public Lanche(String nome, String imgUrl, double preco) {
        this.nome = nome;
        this.imgUrl = imgUrl;
        this.preco = preco;
    }

    public Lanche(int id, String nome, String imgUrl, double preco) {
        this.id = id;
        this.nome = nome;
        this.imgUrl = imgUrl;
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public void setId(int codigo) {
        this.id = codigo;
    }

    public double calcularLanche(int quantidade) {
        return getPreco() * quantidade;
    }

    @Override
    public String toString() {
        return "Lanche{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                ", preco=" + preco +
                '}';
    }
}
