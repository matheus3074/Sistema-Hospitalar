package com.example.atividade_lanche02.repositories;

import com.example.atividade_lanche02.entities.Lanche;
import com.example.atividade_lanche02.interfaces.LancheRepository;
import com.example.atividade_lanche02.repositories.jpa.LancheJpa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;


public class LancheRepositoryMySqlImpl implements LancheRepository {
    private final LancheJpa lancheJpa;

    @Autowired
    public LancheRepositoryMySqlImpl(LancheJpa lancheJpa) {
        this.lancheJpa = lancheJpa;
    }

    @Override
    public Lanche searchByCode(int code) {
        return this.lancheJpa.findById(code).get();
    }

    @Override
    public List<Lanche> buscar() {
        return this.lancheJpa.findAll();
    }

    @Override
    public void addLanches(Lanche lanche) {
        this.lancheJpa.save(lanche);
    }

    @Override
    public void removeLanche(int code) {
        this.lancheJpa.deleteById(code);
    }

    @Override
    public void updateLanche(int code, Lanche lanche) {
        Lanche lancheInDb = this.lancheJpa.findById(code).get();

        lancheInDb.setNome(lanche.getNome());
        lancheInDb.setImgUrl(lanche.getImgUrl());
        lancheInDb.setPreco(lanche.getPreco());

        this.lancheJpa.save(lancheInDb);
    }

    @Override
    public boolean estaVazio() {
        return false;
    }
}
