package com.example.atividade_lanche02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeLanche02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
